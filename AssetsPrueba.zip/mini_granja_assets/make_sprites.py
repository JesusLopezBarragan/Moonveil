import os, random
from PIL import Image, ImageDraw

OUT = "/mnt/user-data/outputs/mini_granja_assets"
for sub in ("tiles", "player", "crops", "icons", "ui"):
    os.makedirs(f"{OUT}/{sub}", exist_ok=True)

def new(w=16, h=16):
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    return im, ImageDraw.Draw(im)

def noise_tile(base, specks, seed, n=22):
    rnd = random.Random(seed)
    im, d = new()
    d.rectangle((0, 0, 15, 15), fill=base)
    for _ in range(n):
        d.point((rnd.randint(0, 15), rnd.randint(0, 15)), fill=rnd.choice(specks))
    return im

# ---------- TILES ----------
grass = noise_tile((98, 168, 72, 255), [(80, 148, 58, 255), (122, 192, 90, 255)], 1)
dirt = noise_tile((156, 112, 72, 255), [(134, 94, 58, 255), (176, 132, 88, 255)], 2)

tilled = noise_tile((124, 84, 52, 255), [(104, 68, 40, 255)], 3, 8)
d = ImageDraw.Draw(tilled)
for y in (3, 7, 11):
    d.line((1, y, 14, y), fill=(98, 62, 36, 255))
    d.line((1, y + 1, 14, y + 1), fill=(146, 102, 66, 255))

wet = tilled.copy()
d = ImageDraw.Draw(wet)
ov = Image.new("RGBA", (16, 16), (40, 50, 90, 90))
wet = Image.alpha_composite(wet, ov)

tiles = {"grass": grass, "dirt": dirt, "tilled": tilled, "tilled_wet": wet}

# decor
rock, d = new()
d.ellipse((2, 5, 13, 14), fill=(120, 122, 130, 255), outline=(70, 72, 80, 255))
d.ellipse((4, 6, 8, 9), fill=(160, 162, 170, 255))
tiles["rock"] = rock

fence, d = new()
d.rectangle((1, 4, 3, 14), fill=(150, 104, 60, 255), outline=(94, 62, 34, 255))
d.rectangle((12, 4, 14, 14), fill=(150, 104, 60, 255), outline=(94, 62, 34, 255))
d.rectangle((3, 6, 12, 7), fill=(176, 126, 74, 255), outline=(94, 62, 34, 255))
d.rectangle((3, 10, 12, 11), fill=(176, 126, 74, 255), outline=(94, 62, 34, 255))
tiles["fence"] = fence

tree, d = new(16, 32)
d.rectangle((6, 18, 9, 30), fill=(112, 78, 46, 255), outline=(70, 46, 26, 255))
d.ellipse((0, 0, 15, 20), fill=(52, 128, 62, 255), outline=(30, 86, 40, 255))
d.ellipse((3, 3, 8, 8), fill=(84, 164, 84, 255))
d.ellipse((8, 9, 12, 13), fill=(70, 148, 72, 255))
tiles["tree"] = tree

for k, v in tiles.items():
    v.save(f"{OUT}/tiles/{k}.png")

# tileset en una fila (4 tiles de suelo)
ts = Image.new("RGBA", (64, 16))
for i, k in enumerate(["grass", "dirt", "tilled", "tilled_wet"]):
    ts.paste(tiles[k], (i * 16, 0))
ts.save(f"{OUT}/tiles/tileset_suelo.png")

# ---------- PLAYER ----------
SKIN = (240, 196, 150, 255); HAIR = (90, 52, 30, 255)
SHIRT = (60, 110, 200, 255); PANTS = (70, 70, 110, 255); SHOE = (80, 50, 30, 255)
EYE = (30, 30, 40, 255)

def player_frame(direction, frame):
    im, d = new()
    d.rectangle((5, 2, 10, 7), fill=SKIN)                      # cabeza
    if direction == "up":
        d.rectangle((5, 2, 10, 6), fill=HAIR)
    else:
        d.rectangle((5, 2, 10, 3), fill=HAIR)
    if direction == "down":
        d.point((6, 5), fill=EYE); d.point((9, 5), fill=EYE)
    elif direction == "left":
        d.point((6, 5), fill=EYE); d.rectangle((9, 3, 10, 5), fill=HAIR)
    elif direction == "right":
        d.point((9, 5), fill=EYE); d.rectangle((5, 3, 6, 5), fill=HAIR)
    d.rectangle((5, 8, 10, 12), fill=SHIRT)                     # torso
    if direction in ("down", "up"):
        d.rectangle((4, 8, 4, 11), fill=SKIN); d.rectangle((11, 8, 11, 11), fill=SKIN)
    else:
        d.rectangle((7, 8, 8, 11), fill=SKIN)
    # piernas
    if frame == 0:
        legs = [(6, 13, 7, 15), (8, 13, 9, 15)]
    elif frame == 1:
        legs = [(6, 12, 7, 14), (8, 13, 9, 15)]
    else:
        legs = [(6, 13, 7, 15), (8, 12, 9, 14)]
    for x0, y0, x1, y1 in legs:
        d.rectangle((x0, y0, x1, y1), fill=PANTS)
        d.point((x0, y1), fill=SHOE); d.point((x1, y1), fill=SHOE)
    return im

dirs = ["down", "up", "left", "right"]
sheet = Image.new("RGBA", (48, 64))
for r, dr in enumerate(dirs):
    for c in range(3):
        f = player_frame(dr, c)
        f.save(f"{OUT}/player/player_{dr}_{c}.png")
        sheet.paste(f, (c * 16, r * 16))
sheet.save(f"{OUT}/player/player_sheet.png")  # filas: abajo, arriba, izq, der | cols: idle, paso1, paso2

# ---------- CROPS ----------
def crop(kind, stage):
    im, d = new()
    G = (64, 150, 64, 255); GD = (40, 110, 48, 255)
    if stage == 0:                      # semilla
        d.ellipse((6, 11, 9, 13), fill=(104, 70, 40, 255))
        d.point((7, 12), fill=(200, 170, 110, 255))
    elif stage == 1:                    # brote
        d.line((8, 14, 8, 10), fill=G)
        d.rectangle((6, 9, 7, 10), fill=G); d.rectangle((9, 8, 10, 9), fill=G)
    else:                               # maduro
        d.line((8, 14, 8, 8), fill=GD)
        if kind == "carrot":
            d.polygon([(8, 9), (5, 3), (7, 5)], fill=G)
            d.polygon([(8, 9), (8, 2), (9, 6)], fill=G)
            d.polygon([(8, 9), (11, 3), (9, 5)], fill=G)
            d.polygon([(6, 10), (10, 10), (8, 14)], fill=(238, 130, 30, 255))
        else:
            d.rectangle((4, 6, 11, 9), fill=G)
            d.ellipse((3, 8, 7, 12), fill=(210, 50, 46, 255))
            d.ellipse((8, 7, 12, 11), fill=(210, 50, 46, 255))
            d.point((4, 9), fill=(250, 150, 140, 255)); d.point((9, 8), fill=(250, 150, 140, 255))
    return im

for kind in ("carrot", "tomato"):
    row = Image.new("RGBA", (48, 16))
    for s in range(3):
        f = crop(kind, s)
        f.save(f"{OUT}/crops/{kind}_{s}.png")
        row.paste(f, (s * 16, 0))
    row.save(f"{OUT}/crops/{kind}_stages.png")

# ---------- ICONS ----------
def icon_carrot():
    im, d = new()
    d.polygon([(5, 5), (11, 5), (8, 15)], fill=(238, 130, 30, 255), outline=(170, 84, 14, 255))
    d.rectangle((6, 1, 7, 4), fill=(64, 150, 64, 255)); d.rectangle((9, 1, 10, 4), fill=(64, 150, 64, 255))
    return im
def icon_tomato():
    im, d = new()
    d.ellipse((2, 4, 13, 14), fill=(210, 50, 46, 255), outline=(140, 28, 28, 255))
    d.rectangle((6, 2, 9, 4), fill=(64, 150, 64, 255))
    d.point((5, 7), fill=(250, 170, 160, 255))
    return im
def icon_seeds(color):
    im, d = new()
    d.rectangle((4, 4, 11, 14), fill=(220, 200, 150, 255), outline=(130, 100, 60, 255))
    d.rectangle((5, 7, 10, 11), fill=color)
    d.line((4, 4, 11, 4), fill=(130, 100, 60, 255))
    return im
def icon_hoe():
    im, d = new()
    d.line((3, 14, 11, 4), fill=(150, 104, 60, 255), width=2)
    d.rectangle((9, 2, 14, 4), fill=(170, 172, 180, 255), outline=(100, 102, 110, 255))
    return im
def icon_can():
    im, d = new()
    d.rectangle((3, 6, 10, 13), fill=(80, 130, 200, 255), outline=(40, 80, 140, 255))
    d.line((10, 8, 14, 5), fill=(80, 130, 200, 255), width=2)
    d.arc((4, 2, 9, 8), 180, 360, fill=(40, 80, 140, 255))
    return im
def icon_coin():
    im, d = new()
    d.ellipse((3, 3, 12, 12), fill=(250, 210, 60, 255), outline=(180, 130, 20, 255))
    d.rectangle((7, 5, 8, 10), fill=(200, 150, 30, 255))
    return im

icons = {"carrot": icon_carrot(), "tomato": icon_tomato(),
         "seeds_carrot": icon_seeds((238, 130, 30, 255)), "seeds_tomato": icon_seeds((210, 50, 46, 255)),
         "hoe": icon_hoe(), "watering_can": icon_can(), "coin": icon_coin()}
for k, v in icons.items():
    v.save(f"{OUT}/icons/{k}.png")

# ---------- UI ----------
def slot(selected):
    im, d = new(20, 20)
    d.rectangle((0, 0, 19, 19), fill=(60, 44, 30, 255))
    d.rectangle((1, 1, 18, 18), fill=(222, 190, 140, 255))
    d.rectangle((2, 2, 17, 17), fill=(190, 150, 100, 255))
    if selected:
        d.rectangle((0, 0, 19, 19), outline=(250, 210, 60, 255))
        d.rectangle((1, 1, 18, 18), outline=(250, 210, 60, 255))
    return im
slot(False).save(f"{OUT}/ui/hotbar_slot.png")
slot(True).save(f"{OUT}/ui/hotbar_slot_selected.png")

def button(hover):
    im, d = new(48, 16)
    d.rectangle((0, 0, 47, 15), fill=(60, 44, 30, 255))
    d.rectangle((1, 1, 46, 14), fill=(236, 206, 150, 255) if hover else (210, 170, 110, 255))
    d.line((1, 14, 46, 14), fill=(160, 120, 70, 255))
    return im
button(False).save(f"{OUT}/ui/button.png")
button(True).save(f"{OUT}/ui/button_hover.png")

chest, d = new()
d.rectangle((1, 6, 14, 14), fill=(150, 104, 60, 255), outline=(70, 46, 26, 255))
d.rectangle((1, 3, 14, 7), fill=(176, 126, 74, 255), outline=(70, 46, 26, 255))
d.rectangle((7, 7, 8, 10), fill=(250, 210, 60, 255))
chest.save(f"{OUT}/ui/sell_chest.png")

# ---------- PREVIEW ----------
items = []
for k in ["grass", "dirt", "tilled", "tilled_wet", "rock", "fence"]: items.append(tiles[k])
for k in ["carrot", "tomato"]:
    for s in range(3): items.append(crop(k, s))
for v in icons.values(): items.append(v)
items.append(chest)
S = 6
W = 12
prev = Image.new("RGBA", (W * 20 * S, 4 * 20 * S + 32 * S), (70, 120, 60, 255))
for i, im in enumerate(items):
    big = im.resize((im.width * S, im.height * S), Image.NEAREST)
    prev.alpha_composite(big, ((i % W) * 20 * S + 2 * S, (i // W) * 20 * S + 2 * S))
big = sheet.resize((48 * S, 64 * S), Image.NEAREST)
prev.alpha_composite(big, (2 * S, 4 * 20 * S - 40 * S + 40 * S))
tb = tree.resize((16 * S, 32 * S), Image.NEAREST)
prev.alpha_composite(tb, (70 * S, 4 * 20 * S - 40 * S + 40 * S))
prev.convert("RGB").save("/home/claude/gen/preview.png")
print("ok")
